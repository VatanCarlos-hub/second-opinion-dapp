# Second Opinion — GenLayer dApp

Decentralized medical second opinion powered by GenLayer's Optimistic Democracy.

**Contract:** `0x4128Ee89B991B80C442333c65AfC267d35BE9Acf`  
**Network:** GenLayer Studionet  
**Contract Methods:** `submit_consultation(symptoms, age)` · `get_verdict()` · `get_differential()`

---

## Setup

```bash
npm install
npm run dev
```

Open `http://localhost:5173`

---

## Deploy to Vercel

```bash
npm install -g vercel
vercel
```

That's it. Vercel auto-detects Vite.

---

## How it works

1. User enters symptoms + age
2. `submit_consultation` is called on-chain via genlayer-js
3. Multiple AI validators (GPT-5, Claude, Qwen, Nemotron...) independently analyze the case
4. Optimistic Democracy consensus is reached
5. `get_verdict` + `get_differential` are called to fetch results
6. Results displayed with differential diagnosis + recommendation

---

## Stack

- React + Vite
- genlayer-js (chain interaction)
- GenLayer Studionet
- DM Sans + DM Mono (typography)
