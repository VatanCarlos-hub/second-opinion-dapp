# v0.2.0
# { "Depends": "py-genlayer:1jb45aa8ynh2a9c9xn3b7qqh8sm5q93hwfp7jqmwsfhh8jpz09h6" }
from genlayer import *

import json


class SecondOpinion(gl.Contract):
    last_symptoms: str
    last_verdict: str
    last_differential: str

    def __init__(self):
        self.last_symptoms = ""
        self.last_verdict = ""
        self.last_differential = ""

    @gl.public.write
    def submit_consultation(self, symptoms: str, age: str) -> None:
        prompt = f"""
You are a medical second opinion AI in a decentralized consensus system.
Patient age: {age}
Symptoms: {symptoms}

Respond using ONLY the following JSON format:
{{
"differential": [
    {{"diagnosis": str, "probability": str, "reasoning": str}},
    {{"diagnosis": str, "probability": str, "reasoning": str}},
    {{"diagnosis": str, "probability": str, "reasoning": str}}
],
"verdict": str,
"recommendation": "URGENT" or "SOON" or "MONITOR"
}}

Rules:
- Always provide exactly 3 diagnoses, ranked by probability (highest first)
- Probability must be a percentage string, e.g. "65%"
- Verdict is a 1-2 sentence summary
- Only JSON, nothing else.
"""

        def get_opinion():
            result = gl.nondet.exec_prompt(prompt)
            result = result.replace("```json", "").replace("```", "")
            return result

        result = gl.eq_principle.prompt_comparative(
            get_opinion,
            "The top diagnosis and recommendation tier (URGENT, SOON, or MONITOR) are the same"
        )
        parsed = json.loads(result)

        diff = parsed["differential"]
        self.last_differential = (
            f"1. {diff[0]['diagnosis']} ({diff[0]['probability']}) — {diff[0]['reasoning']} | "
            f"2. {diff[1]['diagnosis']} ({diff[1]['probability']}) — {diff[1]['reasoning']} | "
            f"3. {diff[2]['diagnosis']} ({diff[2]['probability']}) — {diff[2]['reasoning']}"
        )
        self.last_symptoms = symptoms
        self.last_verdict = parsed["verdict"] + " | " + parsed["recommendation"]

    @gl.public.view
    def get_verdict(self) -> str:
        return self.last_verdict

    @gl.public.view
    def get_differential(self) -> str:
        return self.last_differential

    @gl.public.view
    def get_last_symptoms(self) -> str:
        return self.last_symptoms
