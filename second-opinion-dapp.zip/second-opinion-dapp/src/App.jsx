import { useState, useEffect, useRef } from 'react'
import { createClient, createAccount } from 'genlayer-js'
import { studionet } from 'genlayer-js/chains'

const CONTRACT_ADDRESS = '0x4128Ee89B991B80C442333c65AfC267d35BE9Acf'

const account = createAccount()
const client = createClient({ chain: studionet, account })

const TX_STEPS = ['PENDING', 'PROPOSING', 'COMMITTING', 'REVEALING', 'FINALIZED']

const URGENCY = {
  URGENT:  { bg: 'var(--red-light)',   border: '#F09595', badge: 'var(--red)',   label: 'Urgent — go to ER' },
  SOON:    { bg: 'var(--amber-light)', border: '#EF9F27', badge: 'var(--amber)', label: 'Soon — see a doctor' },
  MONITOR: { bg: 'var(--teal-light)',  border: '#5DCAA5', badge: 'var(--teal)',  label: 'Monitor at home' },
}

function parseDifferential(raw) {
  if (!raw) return []
  return raw.split(' | ').map(entry => {
    const match = entry.match(/^\d+\.\s(.+?)\s\((\d+%)\)\s—\s(.+)$/)
    if (match) return { diagnosis: match[1], probability: match[2], reasoning: match[3] }
    return { diagnosis: entry, probability: '?', reasoning: '' }
  })
}

export default function App() {
  const [phase, setPhase] = useState('idle') // idle | submitting | polling | result | error
  const [symptoms, setSymptoms] = useState('')
  const [age, setAge] = useState('')
  const [txHash, setTxHash] = useState(null)
  const [txStep, setTxStep] = useState(0)
  const [verdict, setVerdict] = useState('')
  const [differential, setDifferential] = useState([])
  const [recommendation, setRecommendation] = useState('MONITOR')
  const [errorMsg, setErrorMsg] = useState('')
  const [copied, setCopied] = useState(false)
  const pollRef = useRef(null)

  useEffect(() => () => clearInterval(pollRef.current), [])

  async function submit() {
    if (!symptoms.trim() || !age.trim()) return
    setPhase('submitting')
    setTxStep(0)
    setErrorMsg('')

    try {
      const hash = await client.writeContract({
        address: CONTRACT_ADDRESS,
        functionName: 'submit_consultation',
        args: [symptoms.trim(), age.trim()],
      })
      setTxHash(hash)
      setPhase('polling')
      setTxStep(1)
      pollTransaction(hash)
    } catch (e) {
      setErrorMsg(e?.message || 'Transaction failed. Check your wallet.')
      setPhase('error')
    }
  }

  function pollTransaction(hash) {
    let step = 1
    pollRef.current = setInterval(async () => {
      try {
        const receipt = await client.getTransactionReceipt({ hash })
        if (!receipt) return

        const status = receipt.status?.toLowerCase() || ''
        if (status.includes('propos')) { step = 1; setTxStep(1) }
        else if (status.includes('commit')) { step = 2; setTxStep(2) }
        else if (status.includes('reveal')) { step = 3; setTxStep(3) }
        else if (status.includes('accept') || status.includes('final')) {
          clearInterval(pollRef.current)
          setTxStep(4)
          setTimeout(() => fetchResults(), 1000)
        } else if (status.includes('error') || status.includes('fail')) {
          clearInterval(pollRef.current)
          setErrorMsg('Transaction failed during consensus. Try again.')
          setPhase('error')
        }
      } catch (e) {
        // still pending, keep polling
      }
    }, 2500)
  }

  async function fetchResults() {
    try {
      const [v, d] = await Promise.all([
        client.readContract({ address: CONTRACT_ADDRESS, functionName: 'get_verdict', args: [] }),
        client.readContract({ address: CONTRACT_ADDRESS, functionName: 'get_differential', args: [] }),
      ])

      const verdictStr = String(v || '')
      const parts = verdictStr.split(' | ')
      const rec = parts.at(-1)?.trim()
      const text = parts.slice(0, -1).join(' | ')

      setVerdict(text || verdictStr)
      setRecommendation(rec && URGENCY[rec] ? rec : 'MONITOR')
      setDifferential(parseDifferential(String(d || '')))
      setPhase('result')
    } catch (e) {
      setErrorMsg('Could not fetch results. Try calling get_verdict manually in Studio.')
      setPhase('error')
    }
  }

  function reset() {
    setPhase('idle')
    setSymptoms('')
    setAge('')
    setTxHash(null)
    setTxStep(0)
    setVerdict('')
    setDifferential([])
    setErrorMsg('')
    clearInterval(pollRef.current)
  }

  function copyResult() {
    const lines = [
      `Second Opinion — GenLayer Consensus`,
      ``,
      `Recommendation: ${recommendation}`,
      `Verdict: ${verdict}`,
      ``,
      `Differential Diagnosis:`,
      ...differential.map((d, i) => `${i + 1}. ${d.diagnosis} (${d.probability}) — ${d.reasoning}`),
      ``,
      `Always consult a licensed physician.`,
      `Powered by GenLayer · ${CONTRACT_ADDRESS}`,
    ]
    navigator.clipboard.writeText(lines.join('\n'))
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const urg = URGENCY[recommendation] || URGENCY.MONITOR

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
          <div style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--teal-mid)' }} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', letterSpacing: '.08em' }}>
            GENLAYER STUDIONET · {CONTRACT_ADDRESS.slice(0, 10)}...{CONTRACT_ADDRESS.slice(-6)}
          </span>
        </div>
        <h1 style={{ fontSize: 28, fontWeight: 500, letterSpacing: '-.02em', lineHeight: 1.2 }}>Second Opinion</h1>
        <p style={{ fontSize: 14, color: 'var(--gray-500)', marginTop: 4 }}>
          AI consensus diagnosis · Decentralized validator network
        </p>
      </div>

      {/* IDLE — Input Form */}
      {phase === 'idle' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={card}>
            <label style={labelStyle}>Symptoms</label>
            <textarea
              value={symptoms}
              onChange={e => setSymptoms(e.target.value)}
              placeholder="Describe your symptoms in detail — the more specific, the better..."
              style={{ width: '100%', minHeight: 100, border: 'none', outline: 'none', background: 'transparent', fontSize: 14, lineHeight: 1.7, resize: 'vertical', color: 'var(--gray-900)', fontFamily: 'var(--font-sans)' }}
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '120px 1fr', gap: 12 }}>
            <div style={card}>
              <label style={labelStyle}>Age</label>
              <input
                type="number"
                value={age}
                onChange={e => setAge(e.target.value)}
                placeholder="30"
                style={{ width: '100%', border: 'none', outline: 'none', background: 'transparent', fontSize: 22, fontWeight: 500, color: 'var(--gray-900)', fontFamily: 'var(--font-sans)' }}
              />
            </div>
            <div style={{ ...card, background: 'var(--gray-100)', border: '0.5px solid var(--gray-300)' }}>
              <p style={{ fontSize: 13, color: 'var(--gray-500)', lineHeight: 1.6 }}>
                Multiple AI validators — GPT-5, Claude, Qwen, Nemotron — independently analyze your case and reach consensus via Optimistic Democracy.
              </p>
            </div>
          </div>

          <button
            onClick={submit}
            disabled={!symptoms.trim() || !age.trim()}
            style={{ ...btnStyle, opacity: (!symptoms.trim() || !age.trim()) ? .4 : 1 }}
          >
            Submit for consensus
          </button>
        </div>
      )}

      {/* SUBMITTING / POLLING */}
      {(phase === 'submitting' || phase === 'polling') && (
        <div style={{ ...card, textAlign: 'center', padding: '2rem 1.5rem' }}>
          <p style={{ fontSize: 13, color: 'var(--gray-500)', marginBottom: '1.25rem' }}>
            {phase === 'submitting' ? 'Submitting transaction...' : 'Validators are processing your case...'}
          </p>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
            {TX_STEPS.map((s, i) => (
              <span key={s} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: 11,
                  padding: '3px 10px',
                  borderRadius: 6,
                  background: i < txStep ? 'var(--teal-light)' : i === txStep ? '#E1F5EE' : 'var(--gray-100)',
                  color: i <= txStep ? 'var(--teal)' : 'var(--gray-500)',
                  fontWeight: i === txStep ? 500 : 400,
                  transition: 'all .4s'
                }}>{s}</span>
                {i < TX_STEPS.length - 1 && <span style={{ fontSize: 11, color: 'var(--gray-300)' }}>→</span>}
              </span>
            ))}
          </div>
          {txHash && (
            <p style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', marginTop: '1rem' }}>
              {txHash.slice(0, 18)}...{txHash.slice(-8)}
            </p>
          )}
        </div>
      )}

      {/* RESULT */}
      {phase === 'result' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>

          {/* Verdict card */}
          <div style={{ ...card, background: urg.bg, borderColor: urg.border }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', letterSpacing: '.06em' }}>
                CONSENSUS VERDICT
              </span>
              <span style={{
                fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 500,
                padding: '3px 12px', borderRadius: 6,
                background: urg.badge, color: '#fff'
              }}>{recommendation} — {urg.label}</span>
            </div>
            <p style={{ fontSize: 15, lineHeight: 1.7, color: 'var(--gray-900)' }}>{verdict}</p>
          </div>

          {/* Differential */}
          {differential.length > 0 && (
            <div style={card}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--gray-500)', letterSpacing: '.06em', display: 'block', marginBottom: '1rem' }}>
                DIFFERENTIAL DIAGNOSIS
              </span>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {differential.map((d, i) => {
                  const pct = parseInt(d.probability) || 0
                  const barColor = i === 0 ? 'var(--teal-mid)' : i === 1 ? 'var(--gray-500)' : 'var(--gray-300)'
                  return (
                    <div key={i}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5 }}>
                        <span style={{ fontSize: 14, fontWeight: 500 }}>{d.diagnosis}</span>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--gray-500)' }}>{d.probability}</span>
                      </div>
                      <div style={{ height: 4, background: 'var(--gray-100)', borderRadius: 2, marginBottom: 5, overflow: 'hidden' }}>
                        <div style={{ height: '100%', width: `${pct}%`, background: barColor, borderRadius: 2, transition: 'width .8s ease' }} />
                      </div>
                      <p style={{ fontSize: 12, color: 'var(--gray-500)', lineHeight: 1.5 }}>{d.reasoning}</p>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* Disclaimer */}
          <div style={{ background: 'var(--gray-100)', borderRadius: 8, padding: '10px 14px' }}>
            <p style={{ fontSize: 12, color: 'var(--gray-500)', lineHeight: 1.5 }}>
              This is an AI second opinion only. Always consult a licensed physician for medical decisions.
              Powered by <a href="https://genlayer.com" style={{ color: 'var(--teal)' }}>GenLayer</a> Optimistic Democracy.
            </p>
          </div>

          {/* Actions */}
          <div style={{ display: 'flex', gap: 10 }}>
            <button onClick={reset} style={{ ...btnStyle, flex: 1 }}>New consultation</button>
            <button onClick={copyResult} style={{ ...btnStyle, flex: 1 }}>
              {copied ? 'Copied!' : 'Copy result'}
            </button>
          </div>
        </div>
      )}

      {/* ERROR */}
      {phase === 'error' && (
        <div style={{ ...card, borderColor: '#F09595', background: 'var(--red-light)' }}>
          <p style={{ fontSize: 14, color: 'var(--red)', marginBottom: 12 }}>{errorMsg}</p>
          <button onClick={reset} style={btnStyle}>Try again</button>
        </div>
      )}
    </div>
  )
}

const card = {
  background: '#fff',
  border: '0.5px solid var(--gray-300)',
  borderRadius: 14,
  padding: '1.1rem 1.25rem',
}
const labelStyle = {
  fontFamily: 'var(--font-mono)',
  fontSize: 11,
  fontWeight: 500,
  color: 'var(--gray-500)',
  letterSpacing: '.06em',
  display: 'block',
  marginBottom: 8,
}
const btnStyle = {
  padding: '13px 20px',
  fontSize: 14,
  fontWeight: 500,
  fontFamily: 'var(--font-sans)',
  background: 'var(--gray-900)',
  color: '#fff',
  border: 'none',
  borderRadius: 10,
  cursor: 'pointer',
}
